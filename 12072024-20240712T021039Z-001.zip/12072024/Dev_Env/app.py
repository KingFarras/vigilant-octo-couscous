import streamlit as st

st.title('Welcome to Streamlit Development Class!')
st.write('We will learning how to create Web Apps using Python programming with Streamlit Library')
st.warning('Stay Tune!')
st.success('Almost there!')
st.header('A...')
st.subheader('B...')
st.balloons()
st.success('Done!')